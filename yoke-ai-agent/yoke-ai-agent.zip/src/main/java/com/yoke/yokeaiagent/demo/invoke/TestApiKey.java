package com.yoke.yokeaiagent.demo.invoke;

/**
 * @author H
 * @project_name yoke-ai-agent
 * @filename TestApiKey
 * @created_date 2025/10/26 18:12
 * @description TestApiKey
 */
public interface TestApiKey {

    String API_KEY = "sk-b3c303a6de554aa2b5289d9b25867263";
}
